from render_common import *
canvas=Image.new('RGB',(1400,650),'#f4f3ef')
d=ImageDraw.Draw(canvas);font=ImageFont.truetype(FONT,26);small=ImageFont.truetype(FONT,19)
d.text((40,20),'UNDERSIDE / FIVE PEN MAGNET POCKETS + CASE RING RECESS',font=font,fill='#233735')
for i,name in enumerate(['A_Open_Spine_Compact','B_Rear_Spine_Extended']):
 t=load_stl(OUT/'stl'/f'{name}.stl')
 roof=np.all(np.abs(t[:,:,2]-4)<.001,axis=1)
 ring=np.all(np.abs(t[:,:,2]-2)<.001,axis=1)
 im=render([(t[~(roof|ring)],(219,210,187)),(t[ring],(145,155,148)),(t[roof],(69,92,94))],w=700,h=510,scale=3.1,rx=180,rz=0)
 canvas.paste(im,(i*700,70))
 d.text((40+700*i,70),('A / COMPACT' if i==0 else 'B / EXTENDED'),font=font,fill='#233735')
 d.text((40+700*i,565),'5 × Ø5.3 × 4 mm blind pockets; Ø5 × 1 mm magnets',font=small,fill='#53615d')
d.text((40,610),'Recesses shaded for clarity • 1 mm solid roofs • Ø5.05 × 2.70 mm spacers supplied • prototype fit and attraction unverified',font=ImageFont.truetype(FONT,16),fill='#895c36')
canvas.save(OUT/'renders'/'underside_magnet_pockets.png')
