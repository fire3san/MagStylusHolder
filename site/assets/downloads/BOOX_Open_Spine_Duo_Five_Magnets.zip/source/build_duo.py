"""Two image-derived BOOX prototypes. All dimensions mm; run with project .venv."""
from geometry import *
import zipfile
OUT=Path(__file__).resolve().parents[1]
Z=9.8
MAGNET_YS=[-48,-38,-12,0,12]
POCKET_D=5.3
POCKET_DEPTH=4.0
def spring(bore=9.6):
    # Right-facing opening: pen peels toward +X, with elastic clip deflection.
    ri=bore/2; ro=ri+1.35
    ts=np.linspace(math.radians(55),math.radians(305),90)
    pts=[(ro*math.cos(t),ro*math.sin(t)) for t in ts]
    pts += [(ri*math.cos(t),ri*math.sin(t)) for t in ts[::-1]]
    return m.CrossSection([pts]).extrude(7).rotate((90,0,0)).translate((0,3.5,Z))
def shape(extended=False):
    # Solid visual disc with an underside recess for the existing annular insert.
    s=cyl(34,3.2)-ring_cut()
    top=57 if extended else 33
    s+=rounded(13,top+72,4.3,5).translate((0,(top-72)/2,0))
    # Raised backbone behind the pen, continuing above the upper clip on version B.
    s+=rounded(2.5,top+66,9.8,1.2).translate((-6.05,(top-66)/2,0))
    ys=[-19,27] if extended else [-27,22]
    for y in ys:s+=spring().translate((0,y,0))
    # Lower protective cup: 3mm axial nib clearance; no pressure on the nib.
    cup=along_y(6.3,21,-61.5,Z)-along_y(4.8,21,-59.5,Z)
    # Open the upper/front half of cup for visibility and tilted extraction.
    cup-=box(15,15,16,(3,-54,Z+8))
    s+=cup
    # Central raised saddle gives each underside pocket a continuous 1mm roof.
    s+=rounded(13,34,5.0,2)
    for y in [-48,-38]:
        s+=rounded(13,9,5.0,2).translate((0,y,0))
    for y in MAGNET_YS:
        s-=cyl(POCKET_D/2,POCKET_DEPTH+.01,(0,y,-.01))
    # Cut last so the longitudinal spine cannot fill the annular hardware recess.
    return s-ring_cut()
def mesh(s):
    q=s.to_mesh()
    return trimesh.Trimesh(np.asarray(q.vert_properties)[:,:3],np.asarray(q.tri_verts),process=True)
def save(name,s):
    assert s.status()==m.Error.NoError
    t=mesh(s); t.export(OUT/'stl'/f'{name}.stl')
    t=trimesh.load_mesh(OUT/'stl'/f'{name}.stl')
    assert t.is_watertight and t.is_winding_consistent and t.volume>0 and len(s.decompose())==1
    return {'size_mm':t.extents.round(3).tolist(),'bounds_mm':t.bounds.round(3).tolist(),'volume_cm3':round(t.volume/1000,3),'watertight':True,'connected_solids':1}
# Nominal cylindrical barrel plus tapered nose; no inference about measured pen shape.
pen=along_y(4.5,145.5,17.75,Z)
pen+=m.Manifold.cylinder(12,.15,4.5,circular_segments=64).rotate((-90,0,0)).translate((0,-67,Z))
checks={}; catalog=[]
for name,extended in [('A_Open_Spine_Compact',False),('B_Rear_Spine_Extended',True)]:
    s=shape(extended); checks[name]=save(name,s)
    collision=(s^pen).volume()
    assert collision<1e-5,collision
    checks[name]['nominal_pen_collision_mm3']=round(collision,6)
    for y in MAGNET_YS:
        pocket=cyl(2.64,3.98,(0,y,.01))
        assert (s^pocket).volume()<1e-6
        magnet=cyl(2.5,1,(0,y,2.8))
        assert (s^magnet).volume()<1e-6
        roof=cyl(2.5,.98,(0,y,4.01))
        assert abs((s^roof).volume()-roof.volume())<1e-5
        assert (ring_cut()^pocket).volume()<1e-6
    assert (s^ring_cut()).volume()<1e-6
    checks[name].update({'underside_magnet_pockets':5,'pocket_diameter_mm':5.3,'pocket_depth_mm':4,'roof_thickness_mm':1.0,'magnet_face_to_nominal_barrel_mm':1.5,'pockets_clear_ring_recess':True,'ring_recess_clear':True})
    catalog.append({'id':name,'spine_top_y_mm':57 if extended else 33,'clip_centres_y_mm':[-19,27] if extended else [-27,22],'clip_bore_mm':9.6,'clip_wall_mm':1.35,'clip_length_mm':7,'opening_direction':'+X sideways; tilt then lift clear of tip cup','ring_recess_OD_ID_depth_mm':[58.4,39.6,2.0],'base_diameter_mm':68,'pen_magnets':{'count':5,'diameter_mm':5,'thickness_mm':1,'centres_y_mm':MAGNET_YS,'pocket_diameter_mm':5.3,'pocket_depth_mm':4,'roof_mm':1,'assumed_adhesive_mm':0.2,'spacer_diameter_mm':5.05,'spacer_thickness_mm':2.7},'pen_tip_y_mm':-67,'pen_tail_y_mm':90.5,'ring_centre_above_device_bottom_mm':75,'holder_bottom_clearance_mm':3,'pen_tail_above_device_top_mm':16.5,'status':'Unvalidated PA12 prototype. Nominal pen envelope, case and release force need physical checks.'})
for b in [9.4,9.6,9.8]:
    save(f'fit_side_clip_{b}',spring(b)+rounded(3,11,9.8,1).translate((-6.2,0,0)))
save('magnet_spacer_5.05x2.70_qty5_per_holder',cyl(2.525,2.7))
(OUT/'checks.json').write_text(json.dumps(checks,indent=2))
(OUT/'catalog.json').write_text(json.dumps(catalog,indent=2))
mesh(pen).export(OUT/'renders'/'nominal_pen.stl')
print(json.dumps(checks,indent=2))
