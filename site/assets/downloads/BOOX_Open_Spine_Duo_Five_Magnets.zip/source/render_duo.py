from render_common import *
from geometry import rounded
import trimesh
def tris(s):
 q=s.to_mesh();return np.asarray(q.vert_properties)[:,:3][np.asarray(q.tri_verts)]
canvas=Image.new('RGB',(1600,1220),'#f4f3ef')
d=ImageDraw.Draw(canvas); title=ImageFont.truetype(FONT,32); small=ImageFont.truetype(FONT,20)
d.text((45,25),'OPEN SPINE / UNDERSIDE MAGNET EDITION',font=title,fill='#233735')
d.text((45,72),'Five underside Ø5 × 1 magnets per holder • exact CAD meshes',font=small,fill='#53615d')
pen=load_stl(OUT/'renders'/'nominal_pen.stl')
device=tris(rounded(109,149,6.8,7,z=-6.8).translate((0,-.5,0)))
for i,(name,label) in enumerate([('A_Open_Spine_Compact','A / COMPACT OPEN SPINE'),('B_Rear_Spine_Extended','B / EXTENDED REAR SPINE')]):
 t=load_stl(OUT/'stl'/f'{name}.stl')
 center=np.array([0,7,0])
 # First row: unmounted geometry, showing the open side.
 im=render([(t-center,(222,215,195)),(pen-center,(64,70,73))],w=800,h=470,scale=2.8,rx=-24,rz=-22)
 canvas.paste(im,(i*800,135))
 d.text((45+i*800,110),label,font=title,fill='#233735')
 # Second row: actual device envelope and installed pen placement.
 im=render([(device,(66,74,77)),(t,(222,215,195)),(pen,(47,53,56))],w=800,h=510,scale=2.9,rx=-12,rz=-12)
 canvas.paste(im,(i*800,620))
 d.text((45+i*800,590),'68 × '+('106' if i==0 else '129')+' × 16.1 | two side-opening clips',font=small,fill='#53615d')
 d.text((45+i*800,1110),'Rear mounted • ring centre 75 mm above device bottom',font=small,fill='#53615d')
d.text((45,1170),'Prototype only: print clip samples first. Fit, release motion and retention are unvalidated.',font=small,fill='#895c36')
canvas.save(OUT/'renders'/'two_products_overview.png')
