# Two Open Spine products for BOOX

Two separate prototypes derived from the selected concept images. This pack does not change the existing website or older models.

| | A: Compact Open Spine | B: Extended Rear Spine |
|---|---|---|
| Reference | First image, compact backbone | Second image, extended upper backbone |
| Printed size, mm | 68 × 106 × 16.1 | 68 × 129 × 16.1 |
| Clip centres relative to ring, mm | −27, +22 | −19, +27 |
| Spine upper end, mm | +33 | +57 |
| Solid mesh volume | 14.498 cm³ | 16.187 cm³ |

Both have a round magnetic base, open backbone, two right-opening C clips and a lower protective cup. The illustrations are translated into a printable starting geometry, rather than traced literally. The intended removal is sideways tilt followed by lifting clear of the cup; a straight sideways translation is obstructed by the cup. Release sweep and flexure forces have not been validated.

## Assumptions and hardware

Reuse the project nominal BOOX envelope of 109 × 149 mm and InkSense Plus envelope of Ø9 × 157.5 mm. Ring centre is assumed 75 mm above the device bottom. The holder bottom is 3 mm above that bottom edge; pen tail projects 16.5 mm above the device top. Actual case geometry and button location must be checked.

Underside annular recess: OD 58.4, ID 39.6, depth 2.0 mm. Use only after checking the purchased ring including adhesive, polarity and mating case. The continuous spine crosses above this recess. Each holder now has five underside-loaded Ø5 × 1 mm pen magnets at y=−48, −38, −12, 0, +12 mm, supplementing the mechanical clips. Attraction to the actual pen is unverified.

Clip bore 9.6 mm, wall 1.35 mm, axial width 7 mm. Side opening is about 7.86 mm at the bore, so a 9 mm pen requires clip deflection. This is an experimental geometry, not a proven spring design. The cup has a closed end at y=−70 mm and nominal nib point at −67 mm, giving 3 mm axial clearance in the model. There is no measured barrel-shoulder stop: verify that sliding cannot force the nib into the end wall. Do not use nib contact as a stop.

## Printing and verification

Start with the 9.4 / 9.6 / 9.8 mm clip samples in SLS/MJF PA12. Try a smooth dummy rod before the pen, then print one full holder for each design. Check roughness, button clearance, insertion force, axial slip, repeated release, case rotation and ring peeling. Hold the base during pen removal. Do not substitute brittle resin for a functional flexure without redesign/testing. Printed samples determine whether the clip opening or wall needs revision.

Both main exported meshes were reopened and checked for watertightness, consistent winding and positive volume; manifold checks confirm one solid. Both have zero static intersection with a nominal cylindrical barrel and simplified tapered nose. See checks.json. These results do not establish actual fit, peel motion, fatigue, magnetic holding force or drop protection.

## Files

- `stl/`: two full holders and three clip-fit samples, all in mm.
- `renders/two_products_overview.png`: comparison rendered from the CAD meshes.
- `catalog.json`: dimensions, placement and assumptions.
- `source/`: editable Python sources. Requires manifold3d, numpy, trimesh and Pillow.

Rebuild from repository root with `.venv/bin/python output/open_spine_duo_five_magnets/source/build_duo.py`, then `.venv/bin/python output/open_spine_duo_five_magnets/source/render_duo.py`.

## Underside magnet assembly

Five Ø5.3 × 4.0 mm blind pockets per holder with continuous 1.0 mm nylon roofs. Pockets do not intersect the annular mounting recess. A raised central saddle supports the roofs without touching the nominal barrel. Both models retain their previous external bounding dimensions. The annular recess is recut after the spine union so it remains open across the spine.

Use five nominal Ø5 × 1 mm magnets and five supplied Ø5.05 × 2.70 mm spacers per holder. These match the v9 hardware assumptions. From the underside: spacer occupies z=0.10–2.80 mm, magnet z=2.80–3.80 mm, and assumed adhesive z=3.80–4.00 mm. The spacer is recessed 0.10 mm; this is not a press fit. Bond magnets and secure spacers separately, accounting for real adhesive thickness. Verify pocket fit, polarity and attraction before bonding. Do not force hardware against the roof. Grade is not specified.

The top magnet face is 1.5 mm below the nominal barrel surface (1.0 mm roof + 0.2 mm assumed adhesive + 0.3 mm air clearance). No magnetic pull force is established. Check actual pen attraction and device function with the assembled holder. Print samples before a full order.

Checks additionally confirm empty pocket volumes, nominal magnet clearance, full roof volumes over each Ø5 mm magnet footprint, and a clear annular recess. The original nonmagnetic duo remains in its separate folder.

## Five-magnet revision

Two extra pockets are at y=−38 and −48 mm, below the circular base and under the nominal full-diameter barrel. Local saddles raise the spine surface to z=5 mm to keep 1 mm roofs; outer bounding dimensions are unchanged. The closest extra pocket is 6.15 mm radially clear of the annular recess. Each holder needs five magnets and five spacers (ten of each for both holders). These locations follow the existing five-magnet products. Verify attraction at each position on the real pen: extra magnets do not establish a higher holding force without testing. Earlier three-magnet files remain in their separate folder.
