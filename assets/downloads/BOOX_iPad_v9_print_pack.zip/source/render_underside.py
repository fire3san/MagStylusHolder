from render_common import *
canvas=Image.new('RGB',(1400,1000),'#f4f3ef')
for i,name in enumerate(['S_Flow_BOOX_vertical','S_Facet_BOOX_vertical']):
 t=load_stl(OUT/'stl'/f'{name}.stl')
 t[:,:,1]+=17
 im=render([(t,(55,107,101))],w=700,h=850,scale=6,rx=145,rz=180)
 d=ImageDraw.Draw(im);d.text((35,30),'FLOW / 5 MAGNETS' if i==0 else 'FACET / 5 MAGNETS',font=ImageFont.truetype(FONT,26),fill='#214649')
 canvas.paste(im,(700*i,0))
d=ImageDraw.Draw(canvas)
d.text((45,900),'Added below ring: Y = -38 and -48 mm. Pocket diameter 5.3 mm.',font=ImageFont.truetype(FONT,25),fill='#214649')
d.text((45,945),'Each BOOX scabbard: 5 x (5 mm diameter / 1 mm thick N52) + 5 spacers.',font=ImageFont.truetype(FONT,23),fill='#65735e')
canvas.save(OUT/'renders'/'five_magnet_underside.png')
